<button
    {{ $attributes->merge([
        'type' => 'button',
        'class' => 'btn-close text-reset',
        'data-bs-dismiss' => 'offcanvas',
        'aria-label' => 'Close',
    ]) }}
></button>
