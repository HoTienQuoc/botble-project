<div {{ $attributes->merge(['class' => 'offcanvas-body']) }}>
    {{ $slot }}
</div>
