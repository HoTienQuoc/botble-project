<div {{ $attributes->merge(['class' => 'row row-cards']) }}>
    {{ $slot }}
</div>
