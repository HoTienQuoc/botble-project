<button
    type="button"
    class="btn-close"
    data-bs-dismiss="modal"
    aria-label="{{ trans('core/base::base.close') }}"
></button>
