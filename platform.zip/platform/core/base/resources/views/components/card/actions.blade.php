<div {{ $attributes->merge(['class' => 'card-actions']) }}>{{ $slot }}</div>
