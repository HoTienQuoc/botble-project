<button {{ $attributes->merge(['class' => 'btn-action']) }}>
    {{ $slot }}
</button>
