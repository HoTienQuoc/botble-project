<p {{ $attributes->merge(['class' => 'card-subtitle']) }}>{{ $slot }}</p>
