@props(['id'])

{{ PanelSectionManager::group($id) }}
