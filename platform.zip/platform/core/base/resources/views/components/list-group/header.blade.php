<div {{ $attributes->merge(['class' => 'list-group-header']) }}>
    {{ $slot }}
</div>
