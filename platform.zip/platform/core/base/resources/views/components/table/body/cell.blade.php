<td {{ $attributes }}>
    {{ $slot }}
</td>
