<tbody {{ $attributes }}>
    {{ $slot }}
</tbody>
