<?php

return [
    'failed' => 'Diese Zugangsdaten stimmen nicht mit unseren Daten überein.',
    'password' => 'Das eingegebene Passwort ist falsch.',
    'throttle' => 'Zu viele Anmeldeversuche. Bitte versuche es in :seconds Sekunden erneut.',
];
