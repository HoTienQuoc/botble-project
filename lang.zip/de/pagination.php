<?php

return [
    'previous' => '« Zurück',
    'next' => 'Weiter »',
];
