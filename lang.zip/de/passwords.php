<?php

return [
    'reset' => 'Dein Passwort wurde zurückgesetzt!',
    'sent' => 'Wir haben dir den Link zum Zurücksetzen des Passworts per E-Mail geschickt!',
    'throttled' => 'Bitte warte, bevor du es erneut versuchst.',
    'token' => 'Dieses Passwort-Zurücksetzungstoken ist ungültig.',
    'user' => 'Wir können keinen Benutzer mit dieser E-Mail-Adresse finden.',
];
